# NovaTech Solutions: Corporate Business Landing Page

A modern, fully responsive corporate landing page for **NovaTech Solutions** built with **React.js (functional components)**, plain **CSS3**, and **Vite**.

> *Innovating Today. Transforming Tomorrow.*

This is a **frontend-only** project. There is no backend, database, API integration, or authentication. The contact form is a frontend demo with validation only.

---

## Features

- 13 sections: Navbar, Hero, About Us, Services, Why Choose Us, Work Process, Projects, Statistics, Testimonials, FAQ, Call-to-Action, Contact, Footer
- Sticky navbar with scroll-spy highlighting, smooth scrolling and a **Let's Talk** button
- Mobile hamburger menu (closes on link click / Escape, locks page scroll while open)
- FAQ accordion (one item open at a time, keyboard accessible)
- Contact form with live frontend validation and a demo success message
- Animated count-up statistics and scroll-reveal animations
- Testimonials: 3-column grid on desktop, slider on tablet / mobile
- Hover effects, subtle animations, back-to-top button
- Responsive for desktop, tablet and mobile
- Accessible: semantic HTML, ARIA attributes, focus styles, skip link, `prefers-reduced-motion` support
- No external images (project previews are inline SVG), so nothing can break or load slowly

## Tech Stack

| Area | Choice |
| --- | --- |
| Framework | React 19 (functional components + hooks) |
| Build tool | Vite |
| Styling | CSS3 (design tokens, Flexbox, Grid) |
| Icons | lucide-react |
| Fonts | Sora + Inter (Google Fonts) |

## Project Structure

```
novatech-solutions/
├── index.html
├── package.json
├── vite.config.js
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx                 # App entry point
    ├── App.jsx                  # Page composition
    ├── data/
    │   └── content.js           # All website text/content in one place
    ├── hooks/
    │   ├── useInView.js         # Scroll-reveal / count-up trigger
    │   └── useActiveSection.js  # Navbar scroll-spy
    ├── utils/
    │   └── validate.js          # Contact form validation rules
    ├── components/
    │   ├── common/              # Reusable: Button, Logo, Reveal, SectionHeading, CountUp, BackToTop
    │   └── sections/            # Navbar, Hero, About, Services, WhyChooseUs, Process,
    │                            # Projects, Stats, Testimonials, FAQ, CTA, Contact, Footer
    └── styles/
        ├── index.css            # Imports all stylesheets
        ├── base.css             # Tokens, reset, buttons, shared UI
        ├── navbar.css
        ├── hero.css
        ├── sections.css
        └── contact-footer.css
```

---

## Installation & Running Locally

**Requirements:** [Node.js](https://nodejs.org/) 18 or newer (check with `node -v`) and npm.

```bash
# 1. Go into the project folder
cd novatech-solutions

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev
```

Open the URL shown in the terminal (usually **http://localhost:5173**).

### Other commands

| Command | Description |
| --- | --- |
| `npm run dev` | Start the development server with hot reload |
| `npm run build` | Create an optimized production build in `dist/` |
| `npm run preview` | Preview the production build locally |
| `npm run lint` | Check the code for problems |

---

## Upload to GitHub

1. Create a free account at [github.com](https://github.com) and sign in.
2. Click **New repository**. Name it `novatech-solutions`, keep it **Public**, and **do not** tick "Add a README" (the project already has one). Click **Create repository**.
3. In the project folder, run:

```bash
git init
git add .
git commit -m "NovaTech Solutions corporate landing page"
git branch -M main
git remote add origin https://github.com/<your-username>/novatech-solutions.git
git push -u origin main
```

Replace `<your-username>` with your GitHub username. If Git asks you to sign in, use your GitHub account (or a Personal Access Token as the password).

`node_modules/` and `dist/` are already excluded by `.gitignore`, so only the source code is uploaded.

---

## Deploy to Vercel

### Option A: From GitHub (recommended)

1. Go to [vercel.com](https://vercel.com) and sign up / log in with your **GitHub** account.
2. Click **Add New → Project**.
3. Select your `novatech-solutions` repository and click **Import**.
4. Vercel detects Vite automatically. Keep the defaults:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
5. Click **Deploy**. After about a minute you get a live URL like `https://novatech-solutions.vercel.app`.

Every future `git push` to `main` redeploys automatically.

### Option B: Vercel CLI

```bash
npm install -g vercel
vercel login
vercel --prod
```

### Before submitting

- [ ] Open the live Vercel URL on a **desktop** browser and click every navigation link
- [ ] Open it on a **mobile** phone and test the hamburger menu, FAQ and contact form
- [ ] Confirm the GitHub repository is **Public** and contains this README

**Submission:** Live Vercel URL + GitHub repository URL + this README.

---

## Contact Details Used in the Site

- Email: hello@novatech.com
- Phone: +91 98765 43210
- Address: Chennai, Tamil Nadu, India

&copy; 2026 NovaTech Solutions. All Rights Reserved.
