import {
  Globe,
  Smartphone,
  PenTool,
  Code2,
  Megaphone,
  Cloud,
  Users,
  Lightbulb,
  ShieldCheck,
  Clock,
  HeartHandshake,
  TrendingUp,
  Search,
  Map,
  Palette,
  Rocket,
} from 'lucide-react'

export const COMPANY = {
  name: 'NovaTech Solutions',
  tagline: 'Innovating Today. Transforming Tomorrow.',
  email: 'hello@novatech.com',
  phone: '+91 98765 43210',
  phoneHref: '+919876543210',
  address: 'Chennai, Tamil Nadu, India',
  year: 2026,
  footerText:
    'Creating innovative digital experiences and technology solutions that empower businesses to achieve more.',
}

export const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About Us', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Our Projects', href: '#projects' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'Contact', href: '#contact' },
]

export const HERO = {
  headline: 'Building Digital Experiences That Drive Business Growth.',
  description:
    'We turn ambitious ideas into powerful digital solutions. From modern websites to intelligent software applications, we help businesses move forward with confidence.',
  highlights: [
    { value: 50, label: 'Projects Delivered' },
    { value: 30, label: 'Happy Clients' },
    { value: 5, label: 'Years of Experience' },
  ],
}

export const ABOUT = {
  heading: 'Technology Meets Creativity',
  paragraphs: [
    'NovaTech Solutions is a technology-driven company dedicated to helping businesses embrace digital transformation. We specialize in creating innovative digital products, scalable software solutions, and user-friendly applications that help organizations improve productivity and achieve sustainable growth.',
    'At NovaTech Solutions, we believe technology should make life easier and businesses stronger. We work closely with our clients to understand their challenges, identify opportunities, and develop solutions that deliver meaningful results. From the initial idea to the final product, our approach focuses on quality, innovation, transparency, and long-term partnerships.',
  ],
  values: ['Quality', 'Innovation', 'Transparency', 'Long-term Partnerships'],
  mission:
    'To empower businesses with reliable, innovative, and accessible technology solutions that simplify operations and accelerate growth.',
  vision:
    'To become a trusted technology partner for businesses worldwide by delivering exceptional digital experiences and future-ready solutions.',
}

export const SERVICES = [
  {
    icon: Globe,
    title: 'Web Development',
    text: 'We create responsive, modern, and high-performance websites that represent your brand and deliver excellent user experiences.',
  },
  {
    icon: Smartphone,
    title: 'Mobile App Development',
    text: 'We develop powerful Android and iOS applications designed to improve customer engagement and simplify everyday business activities.',
  },
  {
    icon: PenTool,
    title: 'UI/UX Design',
    text: 'We transform ideas into visually appealing and user-friendly designs through thoughtful layouts, intuitive navigation, and consistent design systems.',
  },
  {
    icon: Code2,
    title: 'Custom Software Development',
    text: 'We build customized software solutions that automate workflows, solve business challenges, and improve operational efficiency.',
  },
  {
    icon: Megaphone,
    title: 'Digital Marketing',
    text: 'We help businesses strengthen their digital presence through strategic marketing, search engine optimization, and social media engagement.',
  },
  {
    icon: Cloud,
    title: 'Cloud & IT Solutions',
    text: 'We provide scalable cloud-based solutions and IT services that support business performance, security, and growth.',
  },
]

export const WHY_US = {
  heading: 'Your Success Is Our Priority',
  text: 'Choosing the right technology partner makes all the difference. We combine creativity, technical knowledge, and a customer-first approach to deliver solutions that create real value.',
  points: [
    {
      icon: Users,
      title: 'Experienced Professionals',
      text: 'Technical expertise and practical problem-solving skills.',
    },
    {
      icon: Lightbulb,
      title: 'Innovative Approach',
      text: 'Modern technologies and creative ideas for future-ready solutions.',
    },
    {
      icon: ShieldCheck,
      title: 'Quality Assurance',
      text: 'Focus on performance, reliability, and attention to detail.',
    },
    {
      icon: Clock,
      title: 'On-Time Delivery',
      text: 'Structured development processes and respect for project deadlines.',
    },
    {
      icon: HeartHandshake,
      title: 'Customer-Centric Approach',
      text: 'Clear communication and attention to client requirements.',
    },
    {
      icon: TrendingUp,
      title: 'Scalable Solutions',
      text: 'Solutions designed to grow alongside your business.',
    },
  ],
}

export const PROCESS = [
  {
    icon: Search,
    title: 'Discover',
    text: 'Understand business goals, requirements, challenges, and expectations.',
  },
  {
    icon: Map,
    title: 'Plan',
    text: 'Prepare a project roadmap, define scope, and identify suitable technologies.',
  },
  {
    icon: Palette,
    title: 'Design',
    text: 'Create user-friendly layouts and engaging digital experiences.',
  },
  {
    icon: Code2,
    title: 'Develop',
    text: 'Transform approved designs into digital products.',
  },
  {
    icon: Rocket,
    title: 'Test & Deliver',
    text: 'Check quality, performance, and usability before delivery.',
  },
]

export const PROJECTS = [
  {
    variant: 'ecommerce',
    title: 'E-Commerce Platform',
    category: 'Web Development',
    text: 'A modern online shopping platform with intuitive product discovery and a clean interface.',
  },
  {
    variant: 'dashboard',
    title: 'Business Management System',
    category: 'Custom Software',
    text: 'A centralized platform designed to simplify daily operations, improve productivity, and organize business activities.',
  },
  {
    variant: 'fitness',
    title: 'Fitness Mobile Application',
    category: 'Mobile App Development',
    text: 'A user-friendly fitness app to track activities, manage workout routines, and monitor progress.',
  },
  {
    variant: 'corporate',
    title: 'Corporate Website',
    category: 'UI/UX & Web Development',
    text: 'A professional corporate website designed to strengthen brand identity and improve online visibility.',
  },
]

export const STATS = [
  { value: 50, label: 'Successful Projects' },
  { value: 30, label: 'Satisfied Clients' },
  { value: 10, label: 'Technology Experts' },
  { value: 5, label: 'Years of Industry Experience' },
]

export const TESTIMONIALS = [
  {
    quote:
      'NovaTech Solutions understood our business requirements perfectly and delivered a website that exceeded our expectations. Their team was professional and supportive throughout the project.',
    name: 'Arun Kumar',
    role: 'Business Owner',
  },
  {
    quote:
      'We were looking for a reliable technology partner to develop our business application. The team delivered an excellent solution with a great user experience.',
    name: 'Priya Sharma',
    role: 'Startup Founder',
  },
  {
    quote:
      'Excellent communication, creative ideas, and quality development work. We are happy with the overall experience and look forward to working with them again.',
    name: 'Rahul Menon',
    role: 'Managing Director',
  },
]

export const FAQS = [
  {
    q: 'What services does NovaTech Solutions provide?',
    a: 'Web development, mobile app development, UI/UX design, custom software development, digital marketing, and cloud solutions.',
  },
  {
    q: 'Do you develop customized software?',
    a: 'Yes. We develop customized software based on individual business requirements and operational needs.',
  },
  {
    q: 'Can you redesign an existing website?',
    a: 'Yes. We can redesign existing websites with modern layouts, improved usability, and responsive design.',
  },
  {
    q: 'Do you provide support after project delivery?',
    a: 'Yes. Ongoing maintenance and technical support can be provided based on project requirements.',
  },
  {
    q: 'How can I start a project with your team?',
    a: 'Contact us through the website or email. Our team will discuss your requirements and suggest the next steps.',
  },
]

export const CTA = {
  heading: "Have an Idea? Let's Build Something Amazing.",
  text: "Every great digital product starts with an idea. Let's work together to transform your vision into a powerful digital solution.",
}

export const CONTACT = {
  heading: "Let's Start a Conversation",
  text: "Have a project in mind or looking for the right technology partner? We'd love to hear from you. Get in touch with our team, and let's explore how we can help your business grow.",
}

export const FOOTER_LINKS = {
  quick: [
    { label: 'Home', href: '#home' },
    { label: 'About Us', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Portfolio', href: '#projects' },
    { label: 'Contact', href: '#contact' },
  ],
  services: [
    'Web Development',
    'Mobile App Development',
    'UI/UX Design',
    'Custom Software',
    'Digital Marketing',
  ],
}
