import { BarChart3, CheckCircle2, Smartphone, Zap } from 'lucide-react'

const BARS = [38, 62, 48, 80, 58, 92, 70]

/** Decorative product dashboard shown beside the hero text (pure CSS, no images). */
export default function HeroVisual() {
  return (
    <div className="hero-visual" aria-hidden="true">
      <div className="hero-visual__glow" />

      <div className="mock">
        <div className="mock__bar">
          <span />
          <span />
          <span />
          <div className="mock__url">novatech.app/dashboard</div>
        </div>
        <div className="mock__body">
          <div className="mock__side">
            <i className="is-on" />
            <i />
            <i />
            <i />
          </div>
          <div className="mock__main">
            <div className="mock__row">
              <div className="mock__kpi">
                <small>Revenue</small>
                <strong>₹ 12.4L</strong>
                <em>+18%</em>
              </div>
              <div className="mock__kpi">
                <small>Users</small>
                <strong>8,240</strong>
                <em>+9%</em>
              </div>
              <div className="mock__kpi mock__kpi--hide">
                <small>Uptime</small>
                <strong>99.9%</strong>
                <em>Stable</em>
              </div>
            </div>
            <div className="mock__chart">
              {BARS.map((h, i) => (
                <b key={i} style={{ height: `${h}%`, animationDelay: `${i * 90}ms` }} />
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="float-card float-card--a">
        <span className="float-card__icon">
          <CheckCircle2 size={18} />
        </span>
        <div>
          <strong>Project Delivered</strong>
          <small>On time, every time</small>
        </div>
      </div>

      <div className="float-card float-card--b">
        <span className="float-card__icon float-card__icon--cyan">
          <Smartphone size={18} />
        </span>
        <div>
          <strong>iOS &amp; Android</strong>
          <small>Mobile-first apps</small>
        </div>
      </div>

      <div className="float-card float-card--c">
        <span className="float-card__icon float-card__icon--violet">
          <Zap size={18} />
        </span>
        <div>
          <strong>Fast &amp; Scalable</strong>
          <small>Built to grow</small>
        </div>
      </div>

      <div className="float-chip">
        <BarChart3 size={16} /> Growth +42%
      </div>
    </div>
  )
}
