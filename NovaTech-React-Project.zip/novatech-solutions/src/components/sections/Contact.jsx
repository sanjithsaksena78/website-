import { useState } from 'react'
import { CheckCircle2, Mail, MapPin, Phone, Send } from 'lucide-react'
import Reveal from '../common/Reveal'
import SectionHeading from '../common/SectionHeading'
import { COMPANY, CONTACT } from '../../data/content'
import { validateAll, validators } from '../../utils/validate'

const FIELDS = [
  { name: 'fullName', label: 'Full Name', type: 'text', autoComplete: 'name', placeholder: 'John Doe' },
  { name: 'email', label: 'Email Address', type: 'email', autoComplete: 'email', placeholder: 'you@company.com' },
  { name: 'phone', label: 'Phone Number', type: 'tel', autoComplete: 'tel', placeholder: '+91 98765 43210' },
  { name: 'subject', label: 'Subject', type: 'text', autoComplete: 'off', placeholder: 'How can we help?' },
]

const EMPTY = { fullName: '', email: '', phone: '', subject: '', message: '' }

const DETAILS = [
  { icon: Mail, label: 'Email', value: COMPANY.email, href: `mailto:${COMPANY.email}` },
  { icon: Phone, label: 'Phone', value: COMPANY.phone, href: `tel:${COMPANY.phoneHref}` },
  { icon: MapPin, label: 'Address', value: COMPANY.address },
]

export default function Contact() {
  const [values, setValues] = useState(EMPTY)
  const [errors, setErrors] = useState({})
  const [touched, setTouched] = useState({})
  const [sent, setSent] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setValues((prev) => ({ ...prev, [name]: value }))
    setSent(false)
    // Re-validate live once the user has already seen an error for this field.
    if (touched[name]) {
      setErrors((prev) => ({ ...prev, [name]: validators[name](value) }))
    }
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    setTouched((prev) => ({ ...prev, [name]: true }))
    setErrors((prev) => ({ ...prev, [name]: validators[name](value) }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const found = validateAll(values)
    setErrors(found)
    setTouched({ fullName: true, email: true, phone: true, subject: true, message: true })

    if (Object.keys(found).length === 0) {
      // Frontend demo only: no network request is made.
      setSent(true)
      setValues(EMPTY)
      setTouched({})
    } else {
      const first = Object.keys(found)[0]
      document.getElementById(`field-${first}`)?.focus()
    }
  }

  const fieldProps = (name) => ({
    id: `field-${name}`,
    name,
    value: values[name],
    onChange: handleChange,
    onBlur: handleBlur,
    'aria-invalid': errors[name] ? 'true' : 'false',
    'aria-describedby': errors[name] ? `error-${name}` : undefined,
    className: errors[name] ? 'has-error' : '',
  })

  return (
    <section id="contact" className="section contact">
      <div className="container contact__grid">
        <div className="contact__info">
          <SectionHeading eyebrow="Contact" title={CONTACT.heading} subtitle={CONTACT.text} align="left" />

          <ul className="contact__list">
            {DETAILS.map(({ icon: Icon, label, value, href }, i) => (
              <Reveal as="li" key={label} delay={i * 90}>
                <span className="icon-badge icon-badge--sm">
                  <Icon size={20} />
                </span>
                <div>
                  <small>{label}</small>
                  {href ? <a href={href}>{value}</a> : <span>{value}</span>}
                </div>
              </Reveal>
            ))}
          </ul>
        </div>

        <Reveal delay={120} className="contact__card">
          <form onSubmit={handleSubmit} noValidate aria-label="Contact form">
            <div className="form-grid">
              {FIELDS.map((f) => (
                <div className="form-field" key={f.name}>
                  <label htmlFor={`field-${f.name}`}>{f.label}</label>
                  <input type={f.type} autoComplete={f.autoComplete} placeholder={f.placeholder} {...fieldProps(f.name)} />
                  {errors[f.name] && (
                    <p className="form-error" id={`error-${f.name}`} role="alert">
                      {errors[f.name]}
                    </p>
                  )}
                </div>
              ))}

              <div className="form-field form-field--full">
                <label htmlFor="field-message">Your Message</label>
                <textarea rows="5" placeholder="Tell us about your project..." {...fieldProps('message')} />
                {errors.message && (
                  <p className="form-error" id="error-message" role="alert">
                    {errors.message}
                  </p>
                )}
              </div>
            </div>

            <button type="submit" className="btn btn--primary btn--lg btn--block">
              <span>Send Message</span>
              <Send size={18} aria-hidden="true" />
            </button>

            {sent && (
              <p className="form-success" role="status">
                <CheckCircle2 size={20} aria-hidden="true" />
                Thank you! Your message has been received. (Demo only &mdash; nothing was sent.)
              </p>
            )}
          </form>
        </Reveal>
      </div>
    </section>
  )
}
