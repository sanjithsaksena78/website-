import { Mail, MapPin, Phone } from 'lucide-react'
import Logo from '../common/Logo'
import { COMPANY, FOOTER_LINKS } from '../../data/content'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <Logo />
          <p>{COMPANY.footerText}</p>
        </div>

        <nav aria-label="Quick links">
          <h4>Quick Links</h4>
          <ul>
            {FOOTER_LINKS.quick.map((l) => (
              <li key={l.label}>
                <a href={l.href}>{l.label}</a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h4>Services</h4>
          <ul>
            {FOOTER_LINKS.services.map((s) => (
              <li key={s}>
                <a href="#services">{s}</a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4>Contact</h4>
          <ul className="footer__contact">
            <li>
              <Mail size={16} aria-hidden="true" />
              <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a>
            </li>
            <li>
              <Phone size={16} aria-hidden="true" />
              <a href={`tel:${COMPANY.phoneHref}`}>{COMPANY.phone}</a>
            </li>
            <li>
              <MapPin size={16} aria-hidden="true" />
              <span>{COMPANY.address}</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="container footer__bottom">
        <p>
          &copy; {COMPANY.year} {COMPANY.name}. All Rights Reserved.
        </p>
      </div>
    </footer>
  )
}
