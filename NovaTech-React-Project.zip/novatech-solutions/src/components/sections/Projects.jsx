import { ArrowUpRight } from 'lucide-react'
import Reveal from '../common/Reveal'
import SectionHeading from '../common/SectionHeading'
import ProjectVisual from './ProjectVisual'
import { PROJECTS } from '../../data/content'

export default function Projects() {
  return (
    <section id="projects" className="section section--tint">
      <div className="container">
        <SectionHeading
          eyebrow="Our Projects"
          title="Selected Work We Are Proud Of"
          subtitle="A few projects that demonstrate our creativity, technical capabilities, and commitment to quality."
        />

        <div className="projects__grid">
          {PROJECTS.map((project, i) => (
            <Reveal as="article" key={project.title} delay={(i % 2) * 100} className="project-card">
              <div className="project-card__media">
                <ProjectVisual variant={project.variant} />
                <a
                  href="#contact"
                  className="project-card__overlay"
                  aria-label={`Discuss a project like ${project.title}`}
                >
                  <span>
                    Start a similar project <ArrowUpRight size={18} aria-hidden="true" />
                  </span>
                </a>
              </div>
              <div className="project-card__body">
                <span className="tag">{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
