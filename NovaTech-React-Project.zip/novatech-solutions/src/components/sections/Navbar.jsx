import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'
import Logo from '../common/Logo'
import Button from '../common/Button'
import useActiveSection from '../../hooks/useActiveSection'
import { NAV_LINKS } from '../../data/content'

const SECTION_IDS = NAV_LINKS.map((l) => l.href.slice(1))

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const active = useActiveSection(SECTION_IDS)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Lock page scroll while the mobile menu is open and close it with Escape.
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [open])

  // Close the menu automatically when the viewport grows to desktop size.
  useEffect(() => {
    const onResize = () => window.innerWidth > 980 && setOpen(false)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const close = () => setOpen(false)

  return (
    <header className={`navbar ${scrolled || open ? 'navbar--solid' : ''}`}>
      <nav className="container navbar__inner" aria-label="Main navigation">
        <Logo />

        <ul id="primary-menu" className={`navbar__links ${open ? 'is-open' : ''}`}>
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={close}
                className={active === link.href.slice(1) ? 'is-active' : ''}
                aria-current={active === link.href.slice(1) ? 'page' : undefined}
              >
                {link.label}
              </a>
            </li>
          ))}
          <li className="navbar__cta-mobile">
            <Button href="#contact" onClick={close} arrow>
              Let&apos;s Talk
            </Button>
          </li>
        </ul>

        <div className="navbar__actions">
          <Button href="#contact" className="navbar__cta" size="sm">
            Let&apos;s Talk
          </Button>
          <button
            type="button"
            className="navbar__toggle"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            aria-controls="primary-menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>
    </header>
  )
}
