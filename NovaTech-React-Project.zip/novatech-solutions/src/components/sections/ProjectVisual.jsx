/**
 * Illustrated UI previews for the portfolio cards. Drawn as inline SVG so the
 * site has no external images that could break or slow down loading.
 */
const THEMES = {
  ecommerce: ['#6366f1', '#8b5cf6'],
  dashboard: ['#0ea5e9', '#22d3ee'],
  fitness: ['#f97316', '#ec4899'],
  corporate: ['#10b981', '#06b6d4'],
}

function Ecommerce() {
  return (
    <>
      <rect x="40" y="34" width="320" height="192" rx="14" fill="#fff" />
      <rect x="40" y="34" width="320" height="30" rx="14" fill="#eef2ff" />
      <circle cx="58" cy="49" r="4" fill="#fca5a5" />
      <circle cx="72" cy="49" r="4" fill="#fcd34d" />
      <circle cx="86" cy="49" r="4" fill="#86efac" />
      <rect x="260" y="43" width="86" height="12" rx="6" fill="#c7d2fe" />
      {[0, 1, 2].map((i) => (
        <g key={i} transform={`translate(${58 + i * 100} 80)`}>
          <rect width="88" height="76" rx="10" fill={['#e0e7ff', '#fae8ff', '#cffafe'][i]} />
          <circle cx="44" cy="34" r="16" fill={['#818cf8', '#c084fc', '#22d3ee'][i]} opacity=".85" />
          <rect y="84" width="60" height="7" rx="3.5" fill="#cbd5e1" />
          <rect y="98" width="34" height="8" rx="4" fill="#6366f1" />
          <rect x="52" y="96" width="36" height="12" rx="6" fill="#1e1b4b" />
        </g>
      ))}
      <rect x="58" y="196" width="284" height="14" rx="7" fill="#f1f5f9" />
    </>
  )
}

function Dashboard() {
  const bars = [30, 52, 40, 70, 56, 84, 64]
  return (
    <>
      <rect x="36" y="30" width="328" height="200" rx="14" fill="#fff" />
      <rect x="36" y="30" width="62" height="200" rx="14" fill="#0f172a" />
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x="50" y={52 + i * 30} width="34" height="10" rx="5" fill={i === 0 ? '#22d3ee' : '#334155'} />
      ))}
      {[0, 1, 2].map((i) => (
        <g key={i} transform={`translate(${112 + i * 82} 46)`}>
          <rect width="72" height="44" rx="8" fill="#f1f5f9" />
          <rect x="8" y="9" width="30" height="6" rx="3" fill="#94a3b8" />
          <rect x="8" y="24" width="44" height="10" rx="4" fill={['#0ea5e9', '#6366f1', '#10b981'][i]} />
        </g>
      ))}
      <rect x="112" y="104" width="236" height="110" rx="10" fill="#f8fafc" />
      {bars.map((h, i) => (
        <rect key={i} x={126 + i * 32} y={202 - h} width="18" height={h} rx="5" fill={i === 5 ? '#0ea5e9' : '#bae6fd'} />
      ))}
    </>
  )
}

function Fitness() {
  return (
    <>
      <rect x="140" y="14" width="120" height="232" rx="22" fill="#0f172a" />
      <rect x="148" y="26" width="104" height="208" rx="15" fill="#fff" />
      <rect x="180" y="18" width="40" height="6" rx="3" fill="#1e293b" />
      <circle cx="200" cy="92" r="32" fill="none" stroke="#fde4cf" strokeWidth="10" />
      <path d="M200 60a32 32 0 1 1-30 42" fill="none" stroke="#f97316" strokeWidth="10" strokeLinecap="round" />
      <rect x="182" y="86" width="36" height="9" rx="4" fill="#0f172a" />
      <rect x="188" y="100" width="24" height="5" rx="2.5" fill="#94a3b8" />
      {[0, 1, 2].map((i) => (
        <g key={i} transform={`translate(160 ${142 + i * 30})`}>
          <rect width="80" height="22" rx="8" fill="#fff1f2" />
          <circle cx="12" cy="11" r="6" fill={['#f97316', '#ec4899', '#8b5cf6'][i]} />
          <rect x="24" y="8" width="38" height="6" rx="3" fill="#cbd5e1" />
        </g>
      ))}
      <rect x="64" y="70" width="58" height="36" rx="10" fill="#fff" opacity=".95" />
      <rect x="74" y="80" width="26" height="6" rx="3" fill="#f97316" />
      <rect x="74" y="92" width="38" height="6" rx="3" fill="#cbd5e1" />
      <rect x="282" y="150" width="62" height="36" rx="10" fill="#fff" opacity=".95" />
      <rect x="292" y="160" width="28" height="6" rx="3" fill="#ec4899" />
      <rect x="292" y="172" width="40" height="6" rx="3" fill="#cbd5e1" />
    </>
  )
}

function Corporate() {
  return (
    <>
      <rect x="34" y="30" width="332" height="200" rx="14" fill="#fff" />
      <rect x="34" y="30" width="332" height="26" rx="14" fill="#ecfdf5" />
      <rect x="52" y="39" width="40" height="8" rx="4" fill="#10b981" />
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x={208 + i * 38} y="40" width="28" height="6" rx="3" fill="#a7f3d0" />
      ))}
      <rect x="52" y="76" width="150" height="14" rx="7" fill="#0f172a" />
      <rect x="52" y="98" width="110" height="14" rx="7" fill="#0f172a" />
      <rect x="52" y="124" width="130" height="6" rx="3" fill="#cbd5e1" />
      <rect x="52" y="136" width="116" height="6" rx="3" fill="#cbd5e1" />
      <rect x="52" y="156" width="64" height="20" rx="10" fill="#10b981" />
      <rect x="226" y="72" width="120" height="104" rx="12" fill="#d1fae5" />
      <circle cx="286" cy="118" r="26" fill="#34d399" opacity=".8" />
      <path d="M240 168l32-34 24 22 22-28 28 40z" fill="#059669" opacity=".55" />
      {[0, 1, 2].map((i) => (
        <rect key={i} x={52 + i * 100} y="192" width="88" height="26" rx="8" fill="#f1f5f9" />
      ))}
    </>
  )
}

const SCENES = { ecommerce: Ecommerce, dashboard: Dashboard, fitness: Fitness, corporate: Corporate }

export default function ProjectVisual({ variant }) {
  const [from, to] = THEMES[variant]
  const Scene = SCENES[variant]
  const id = `pv-${variant}`
  return (
    <svg viewBox="0 0 400 260" role="img" aria-hidden="true" className="project-visual" preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={from} />
          <stop offset="1" stopColor={to} />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${id})`} />
      <circle cx="360" cy="30" r="80" fill="#fff" opacity=".1" />
      <circle cx="30" cy="250" r="90" fill="#fff" opacity=".08" />
      <Scene />
    </svg>
  )
}
