import Reveal from '../common/Reveal'
import SectionHeading from '../common/SectionHeading'
import { WHY_US } from '../../data/content'

export default function WhyChooseUs() {
  return (
    <section id="why-us" className="section">
      <div className="container why__grid">
        <div className="why__intro">
          <SectionHeading eyebrow="Why Choose Us?" title={WHY_US.heading} align="left" />
          <Reveal as="p" delay={100} className="why__text">
            {WHY_US.text}
          </Reveal>
        </div>

        <div className="why__list">
          {WHY_US.points.map(({ icon: Icon, title, text }, i) => (
            <Reveal key={title} delay={(i % 2) * 90} className="why-item">
              <span className="icon-badge icon-badge--sm">
                <Icon size={22} />
              </span>
              <div>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
