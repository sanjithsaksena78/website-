import Button from '../common/Button'
import CountUp from '../common/CountUp'
import HeroVisual from './HeroVisual'
import { HERO, COMPANY } from '../../data/content'

export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="hero__bg" aria-hidden="true">
        <span className="orb orb--1" />
        <span className="orb orb--2" />
        <span className="grid-pattern" />
      </div>

      <div className="container hero__inner">
        <div className="hero__content">
          <span className="hero__badge">
            <i /> {COMPANY.tagline}
          </span>
          <h1>
            Building Digital Experiences That <span className="gradient-text">Drive Business Growth.</span>
          </h1>
          <p className="hero__lead">{HERO.description}</p>

          <div className="hero__buttons">
            <Button href="#services" arrow>
              Explore Our Services
            </Button>
            <Button href="#contact" variant="outline-light">
              Start a Project
            </Button>
          </div>

          <ul className="hero__stats">
            {HERO.highlights.map((item) => (
              <li key={item.label}>
                <strong>
                  <CountUp value={item.value} />
                </strong>
                <span>{item.label}</span>
              </li>
            ))}
          </ul>
        </div>

        <HeroVisual />
      </div>
    </section>
  )
}
