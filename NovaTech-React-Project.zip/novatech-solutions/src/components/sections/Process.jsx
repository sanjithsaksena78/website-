import Reveal from '../common/Reveal'
import SectionHeading from '../common/SectionHeading'
import { PROCESS } from '../../data/content'

export default function Process() {
  return (
    <section id="process" className="section section--dark process">
      <div className="container">
        <SectionHeading
          eyebrow="Our Work Process"
          title="A Clear Path From Idea to Launch"
          subtitle="Five simple steps keep every project transparent, predictable and on track."
          light
        />

        <ol className="process__steps">
          {PROCESS.map(({ icon: Icon, title, text }, i) => (
            <Reveal as="li" key={title} delay={i * 100} className="process-step">
              <div className="process-step__top">
                <span className="process-step__icon">
                  <Icon size={26} />
                </span>
                <span className="process-step__num">{String(i + 1).padStart(2, '0')}</span>
              </div>
              <h3>{title}</h3>
              <p>{text}</p>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  )
}
