import { ArrowUpRight } from 'lucide-react'
import Reveal from '../common/Reveal'
import SectionHeading from '../common/SectionHeading'
import { SERVICES } from '../../data/content'

export default function Services() {
  return (
    <section id="services" className="section section--tint">
      <div className="container">
        <SectionHeading
          eyebrow="Our Services"
          title="Solutions That Move Your Business Forward"
          subtitle="From first idea to final launch, we cover every part of your digital journey."
        />

        <div className="services__grid">
          {SERVICES.map(({ icon: Icon, title, text }, i) => (
            <Reveal key={title} delay={(i % 3) * 90} className="service-card">
              <span className="icon-badge">
                <Icon size={26} />
              </span>
              <h3>{title}</h3>
              <p>{text}</p>
              <a href="#contact" className="link-arrow" aria-label={`Talk to us about ${title}`}>
                Learn more <ArrowUpRight size={16} aria-hidden="true" />
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
