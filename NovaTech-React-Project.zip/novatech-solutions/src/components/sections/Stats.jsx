import { Award, Briefcase, Cpu, Smile } from 'lucide-react'
import Reveal from '../common/Reveal'
import CountUp from '../common/CountUp'
import { STATS } from '../../data/content'

const ICONS = [Briefcase, Smile, Cpu, Award]

export default function Stats() {
  return (
    <section id="stats" className="stats" aria-label="Achievements">
      <div className="container stats__grid">
        {STATS.map((stat, i) => {
          const Icon = ICONS[i]
          return (
            <Reveal key={stat.label} delay={i * 90} className="stat">
              <span className="stat__icon">
                <Icon size={24} />
              </span>
              <strong>
                <CountUp value={stat.value} />
              </strong>
              <span>{stat.label}</span>
            </Reveal>
          )
        })}
      </div>
    </section>
  )
}
