import Button from '../common/Button'
import Reveal from '../common/Reveal'
import { COMPANY, CTA as CTA_CONTENT } from '../../data/content'

export default function CTA() {
  return (
    <section id="cta" className="cta">
      <div className="container">
        <Reveal className="cta__box">
          <span className="cta__glow" aria-hidden="true" />
          <h2>{CTA_CONTENT.heading}</h2>
          <p>{CTA_CONTENT.text}</p>
          <div className="cta__buttons">
            <Button href="#contact" variant="light" arrow>
              Start Your Project
            </Button>
            <Button href={`mailto:${COMPANY.email}`} variant="outline-light">
              Contact Our Team
            </Button>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
