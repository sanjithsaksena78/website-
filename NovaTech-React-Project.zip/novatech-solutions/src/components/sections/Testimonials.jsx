import { useState } from 'react'
import { ChevronLeft, ChevronRight, Quote, Star } from 'lucide-react'
import Reveal from '../common/Reveal'
import SectionHeading from '../common/SectionHeading'
import { TESTIMONIALS } from '../../data/content'

const initials = (name) =>
  name
    .split(' ')
    .map((n) => n[0])
    .join('')

export default function Testimonials() {
  const [index, setIndex] = useState(0)
  const total = TESTIMONIALS.length
  const go = (next) => setIndex((next + total) % total)

  return (
    <section id="testimonials" className="section">
      <div className="container">
        <SectionHeading
          eyebrow="Client Testimonials"
          title="What Our Clients Say About Us"
          subtitle="Real feedback from the people we have built products with."
        />

        <div className="testimonials__grid">
          {TESTIMONIALS.map((t, i) => (
            <Reveal
              as="figure"
              key={t.name}
              delay={i * 100}
              className={`testimonial ${i === index ? 'is-active' : ''}`}
            >
              <Quote className="testimonial__quote" size={34} aria-hidden="true" />
              <div className="stars" aria-label="5 out of 5 stars">
                {[...Array(5)].map((_, s) => (
                  <Star key={s} size={16} fill="currentColor" aria-hidden="true" />
                ))}
              </div>
              <blockquote>&ldquo;{t.quote}&rdquo;</blockquote>
              <figcaption>
                <span className="avatar" aria-hidden="true">
                  {initials(t.name)}
                </span>
                <span>
                  <strong>{t.name}</strong>
                  <small>{t.role}</small>
                </span>
              </figcaption>
            </Reveal>
          ))}
        </div>

        <div className="testimonials__controls" role="group" aria-label="Testimonial navigation">
          <button type="button" onClick={() => go(index - 1)} aria-label="Previous testimonial">
            <ChevronLeft size={20} />
          </button>
          <div className="dots">
            {TESTIMONIALS.map((t, i) => (
              <button
                key={t.name}
                type="button"
                className={i === index ? 'is-active' : ''}
                onClick={() => go(i)}
                aria-label={`Show testimonial from ${t.name}`}
                aria-current={i === index}
              />
            ))}
          </div>
          <button type="button" onClick={() => go(index + 1)} aria-label="Next testimonial">
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </section>
  )
}
