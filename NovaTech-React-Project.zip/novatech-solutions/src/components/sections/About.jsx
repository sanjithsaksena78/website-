import { Eye, Target, CheckCircle2 } from 'lucide-react'
import Reveal from '../common/Reveal'
import SectionHeading from '../common/SectionHeading'
import { ABOUT } from '../../data/content'

export default function About() {
  return (
    <section id="about" className="section about">
      <div className="container about__grid">
        <div className="about__text">
          <SectionHeading eyebrow="About Us" title={ABOUT.heading} align="left" />
          {ABOUT.paragraphs.map((p, i) => (
            <Reveal as="p" key={i} delay={80 * (i + 1)} className="about__p">
              {p}
            </Reveal>
          ))}
          <Reveal as="ul" delay={240} className="about__values">
            {ABOUT.values.map((v) => (
              <li key={v}>
                <CheckCircle2 size={18} aria-hidden="true" /> {v}
              </li>
            ))}
          </Reveal>
        </div>

        <div className="about__cards">
          <Reveal className="mv-card" delay={100}>
            <span className="icon-badge">
              <Target size={24} />
            </span>
            <h3>Our Mission</h3>
            <p>{ABOUT.mission}</p>
          </Reveal>
          <Reveal className="mv-card mv-card--alt" delay={220}>
            <span className="icon-badge icon-badge--cyan">
              <Eye size={24} />
            </span>
            <h3>Our Vision</h3>
            <p>{ABOUT.vision}</p>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
