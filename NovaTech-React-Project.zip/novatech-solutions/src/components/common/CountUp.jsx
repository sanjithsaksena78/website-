import { useEffect, useState } from 'react'
import useInView from '../../hooks/useInView'

/** Animates from 0 to `value` once visible, then shows `value` + suffix (e.g. "50+"). */
export default function CountUp({ value, suffix = '+', duration = 1400 }) {
  const [ref, inView] = useInView({ threshold: 0.4 })
  const [count, setCount] = useState(0)
  const reduceMotion =
    typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

  useEffect(() => {
    if (!inView || reduceMotion) return undefined
    let frame
    const start = performance.now()
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.round(value * eased))
      if (progress < 1) frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [inView, reduceMotion, value, duration])

  return (
    <span ref={ref}>
      {reduceMotion ? value : count}
      {suffix}
    </span>
  )
}
