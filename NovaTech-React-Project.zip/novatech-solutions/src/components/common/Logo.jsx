export default function Logo({ href = '#home' }) {
  return (
    <a href={href} className="logo" aria-label="NovaTech Solutions home">
      <svg className="logo__mark" viewBox="0 0 64 64" aria-hidden="true">
        <defs>
          <linearGradient id="logoGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#6366f1" />
            <stop offset="1" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
        <rect width="64" height="64" rx="16" fill="rgba(99,102,241,0.16)" />
        <path
          d="M18 46V18l28 28V18"
          fill="none"
          stroke="url(#logoGrad)"
          strokeWidth="7"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span className="logo__text">
        Nova<strong>Tech</strong>
        <small>Solutions</small>
      </span>
    </a>
  )
}
