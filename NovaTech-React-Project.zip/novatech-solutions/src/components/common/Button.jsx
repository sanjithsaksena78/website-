import { ArrowRight } from 'lucide-react'

/**
 * Link-styled button. Pass `href` for anchors / mailto links,
 * or `type` + `onClick` for real <button> elements.
 */
export default function Button({
  href,
  variant = 'primary',
  size = 'md',
  arrow = false,
  children,
  className = '',
  ...rest
}) {
  const classes = `btn btn--${variant} btn--${size} ${className}`.trim()
  const content = (
    <>
      <span>{children}</span>
      {arrow && <ArrowRight size={18} aria-hidden="true" />}
    </>
  )

  if (href) {
    return (
      <a href={href} className={classes} {...rest}>
        {content}
      </a>
    )
  }
  return (
    <button className={classes} {...rest}>
      {content}
    </button>
  )
}
