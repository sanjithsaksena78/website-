/** Frontend-only validation rules for the contact form (nothing is sent to a server). */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
const PHONE_RE = /^\+?[0-9][0-9\s-]{8,14}[0-9]$/

export const validators = {
  fullName: (v) => {
    if (!v.trim()) return 'Please enter your full name.'
    if (v.trim().length < 2) return 'Name must be at least 2 characters.'
    return ''
  },
  email: (v) => {
    if (!v.trim()) return 'Please enter your email address.'
    if (!EMAIL_RE.test(v.trim())) return 'Please enter a valid email address.'
    return ''
  },
  phone: (v) => {
    if (!v.trim()) return 'Please enter your phone number.'
    if (!PHONE_RE.test(v.trim())) return 'Please enter a valid phone number (10-15 digits).'
    return ''
  },
  subject: (v) => {
    if (!v.trim()) return 'Please enter a subject.'
    if (v.trim().length < 3) return 'Subject must be at least 3 characters.'
    return ''
  },
  message: (v) => {
    if (!v.trim()) return 'Please write your message.'
    if (v.trim().length < 10) return 'Message must be at least 10 characters.'
    return ''
  },
}

export function validateAll(values) {
  const errors = {}
  Object.keys(validators).forEach((key) => {
    const msg = validators[key](values[key] ?? '')
    if (msg) errors[key] = msg
  })
  return errors
}
